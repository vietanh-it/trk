<?php
/**
 * Created by PhpStorm.
 * User: vietanh
 * Date: 03/06/2016
 * Time: 11:55
 */

phpinfo();